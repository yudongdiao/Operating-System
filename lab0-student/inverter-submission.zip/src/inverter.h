#include <stdlib.h>
#include <string>
#include <iostream>
#include <fstream>

using namespace std;

string build_inverted_index(string filename);
